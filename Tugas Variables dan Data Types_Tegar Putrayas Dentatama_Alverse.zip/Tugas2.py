# Tegar Putrayas Dentatama / Alverse
# Tugas 2: Konversi Tipe Data dan Input Pengguna

# langkah pertama meminta input dari pengguna
# fungsi input() digunakan untuk menampilkan pesan kepada pengguna dan menerima input yang diberikan oleh pengguna.
# pengguna diminta untuk memasukkan jumlah pesanan kopi dan input() akan menyimpannya di variabel jumlah_kopi_str
jumlah_kopi_str = input("Masukkan jumlah pesanan kopi: ")

# meminta pengguna untuk memasukkan jumlah pesanan roti dan input() akan menyimpannya di variabel jumlah_roti_str
jumlah_roti_str = input("Masukkan jumlah pesanan roti: ")

# langkah kedua adalah memeriksa tipe data awal menggunakan fungsi type().
# tipe data pertama dari variabel input adalah string
print("\n    Memeriksa Tipe Data Awal\n")
print("Tipe data awal jumlah kopi:", type(jumlah_kopi_str))
print("Tipe data awal jumlah roti:", type(jumlah_roti_str))

# langkah ketiga adalah mengubah tipe data atau melakukan konversi tipe data.
# karena input awal adalah string, maka operasi matematika belum bisa digunakan.
# sehingga perlu mengubah input awal menjadi integer (bilangan bulat) menggunakan fungsi int().
# mengonversi jumlah_kopi_str menjadi integer dan menyimpannya di variabel baru
jumlah_kopi_int = int(jumlah_kopi_str)

# mengonversi jumlah_roti_str menjadi integer dan menyimpannya di variabel baru
jumlah_roti_int = int(jumlah_roti_str)

# langkah keempat adalah memeriksa kembali tipe data setelah konversi.
print("\n    Memeriksa Tipe Data Setelah Konversi\n")
print("Tipe data jumlah kopi setelah konversi:", type(jumlah_kopi_int))
print("Tipe data jumlah roti setelah konversi:", type(jumlah_roti_int))