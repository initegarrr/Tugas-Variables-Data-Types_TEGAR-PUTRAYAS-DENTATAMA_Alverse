
# Tegar Putrayas Dentatama / Alverse
# Tugas 1: Menyimpan dan Menampilkan Data
# dibawah ini akan ada lima variabel untuk menyimpan informasi dari produk.
# variabel untuk menyimpan nama produk pertama (menggunakan tipe data string)
nama_produk_1 = "Kopi Pagi"

# variabel untuk menyimpan harga dari produk pertama (menggunakan tipe data float karena ada desimal)
harga_produk_1 = 18000.5

# variabel untuk menyimpan nama produk kedua (menggunakan tipe data string)
nama_produk_2 = "Roti Cokelat"

# variabel untuk menyimpan harga dari produk kedua (menggunakan tipe data integer karena bilangan bulat)
harga_produk_2 = 10000

# variabel untuk menyimpan status ketersediaan (menggunakan tipe data boolean karena menentukan keputusan True atau False dari variabel)
status_ketersediaan_roti = True

# dibawah ini adalah perintah untuk mencetak output/keluaran/hasil yang berisi sesuai dengan variabel sebelumnya.

print("Nama Produk 1:", nama_produk_1)
print("Harga Produk 1:", harga_produk_1)
print("Nama Produk 2:", nama_produk_2)
print("Harga Produk 2:", harga_produk_2)
print("Status Petersediaan Roti:", status_ketersediaan_roti)