# Tegar Putrayas Dentatama / Alverse
# Tugas 3: Operasi pada Angka

# variabel dari Tugas 1 (harga produk)
harga_kopi = 18000.5
harga_roti = 10000

# variabel dari Tugas 2 (jumlah pesanan setelah dikonversi ke integer)
jumlah_kopi_int = 2
jumlah_roti_int = 3

print("     Rincian Perhitungan Belanja \n")

# langkah pertama adalah menghitung total harga kopi.
# operasi perkalian dibutuhkan untuk mengalikan harga satuan kopi dengan jumlah pesanan kopi.
# sehingga operator perkalian yang digunakan adalah '*'
total_harga_kopi = harga_kopi * jumlah_kopi_int
print("Total harga kopi:", total_harga_kopi)

# langkah kedua adalah menghitung total harga roti.
# sama seperti mementukan total harga kopi.
total_harga_roti = harga_roti * jumlah_roti_int
print("Total harga roti:", total_harga_roti)

# langkah ketiga adlaah menghitung total harga keseluruhan lalu mencetaknya.
# jumlahkan total harga kopi dan total harga roti.
# operator penjumlahan yang digunakan adalah '+'
total_belanja = total_harga_kopi + total_harga_roti
print("Total belanja keseluruhan:", total_belanja)

# langkah keempat adalah menghitung uang kembalian.
# variabel baru dibuat untuk menyimpan jumlah uang yang dibayarkan.
uang_bayar = 50000
print("Uang yang dibayarkan:", uang_bayar)

# setelah pengguna memasukan input uang yang dibayarkan.
# maka input tersebut akan dikurangi dengan total belanja.
# operator pengurangan yang digunakan adalah '-'
kembalian = uang_bayar - total_belanja
print("Kembalian:", kembalian)