# Tegar Putrayas Dentatama / Alverse
# Tugas 4: Operasi pada String
# variabel dari tugas3.
nama_kopi = "Kopi Pagi"
total_harga_kopi = 36001.0 # hasil perhitungan dari Tugas 3 (18000.5 * 2)

# langkah pertama adalah membuat variabel input nama pelanggan.
# menggunakan fungsi input() untuk meminta input nama pelanggan dari pengguna dan menyimpannya.
nama_pelanggan = input("Silakan masukkan nama Anda: ")

# langkah kedua adalah menggabungkan teks untuk menghasilkan output sesuai dengan yang ada di soal.
# untuk menggabungkan beberapa string menjadi satu kalimat utuh, maka dibutuhkan operator '+'
pesan_terima_kasih = "Terima kasih, " + nama_pelanggan + " sudah berbelanja di Coffee Shop Bahagia!"

# langkah ketiga adalah membuat garis pemisah.
# dilangkah ini akan terjadi pengulangan karakter '*' sebanyak 25 kali untuk membuat garis pemisah.
# sehingga membutuhkan operator perkalian '*' pada string untuk mengulang string tersebut.
garis_pemisah = "*" * 25

# cetak garis pemisah di bagian atas.
print(garis_pemisah)

# langkah keempat adlaah mencetak pesan terima kasih yang sudah digabungkan.
print(pesan_terima_kasih)

# cetak garis pemisah di bagian bawah
print(garis_pemisah)

# langkah kelima adlaah mencetak pesan menggunakan formatted string.
# formatted string adalah cara modern dan mudah untuk memasukkan nilai variabel langsung ke dalam sebuah string.
# variabel yang ingin dimasukkan ditulis di dalam kurung kurawal {}.
pesan_harga = f"Total harga {nama_kopi} adalah Rp{total_harga_kopi}"
print(pesan_harga)